void timer_init(uint32_t freq_hz) {

}

void timer_handler() {

}

uint get_ticks() {

}

void sleep(uint ms) {

}


