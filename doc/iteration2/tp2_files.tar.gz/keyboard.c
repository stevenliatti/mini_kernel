#include "keyboard.h"

void keyboard_init() {

}

void keyboard_handler() {

}

int getc() {

}

// Non-blocking call. Return 1 if a key is pressed
int keypressed() {

}

